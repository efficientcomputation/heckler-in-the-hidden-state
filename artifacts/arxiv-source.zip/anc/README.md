# Supplementary code and result data

This directory accompanies A Heckler in the Hidden State: Correctness Signals in Diffusion Language Models. It includes the available research scripts, compact result summaries, and the inputs needed to redraw seven figures.

From this directory, install requirements/figures.txt, then run:

```bash
python scripts/manifest.py
python scripts/plot_figures.py
```

Figures are written to build/figures/. See docs/EXPERIMENTS.md for experimental settings and dependencies, and docs/PROVENANCE.md for the source mapping. The complete manuscript sources are one directory above this one. This compact tree includes the plot and manifest scripts; its docs/REPRODUCING.md gives direct XeLaTeX commands for the enclosing manuscript. The compact supplement does not include model weights or activation shards.
