# Reproducing figures and building the paper

The seven graph PDFs can be regenerated from the supplied result data without running a language model. The two schematic diagrams are drawn by TikZ when the manuscript compiles.

## Python environment

The figure workflow was tested with Python 3.12.13, Matplotlib 3.10.7, and NumPy 2.5.3. From the ancillary directory:

```bash
python -m venv .venv
.venv/bin/python -m pip install -r requirements/figures.txt
.venv/bin/python scripts/manifest.py
.venv/bin/python scripts/plot_figures.py
```

The manifest command checks the files under `code/`, `data/`, `docs/`, `requirements/`, and `scripts/`, plus the README and `.gitignore`. After an intentional edit, refresh it with `python scripts/manifest.py --write`.

The plot command writes seven PDFs to `build/figures/`, PNG previews to `build/checks/`, and `build/checks/figure_data_manifest.json`. Successful completion prints `verified frozen manuscript coordinates for all seven figures`. This means the plotted coordinates agree with both `code/plotting_reference.py` and `data/figure_values.json`. It does not rerun the experiments or recompute their statistical estimates. The script accepts `--output-root PATH` to place the output elsewhere.

The data guide explains each input file. The four-bar steering and four-model comparison plots retain numeric constants from the original plotting code; they are not calculated from the separate eleven-arm steering campaign.

## Compile the accompanying manuscript

This guide is distributed inside the arXiv package's `anc/` directory. The manuscript sources (`main.tex`, `appendix.tex`, `main.bbl`, and `figures/`) are in its parent directory. From `anc/`, compile them with:

```bash
cd ..
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error main.tex
```

The full repository's paper-build and ZIP-packaging wrappers are not included in this compact ancillary tree. The figure-redraw and manifest commands above run directly from `anc/`. The enclosing archive is already the submission source package; no extra packaging step is needed here.

## Repeating experiments

The supplied research scripts are preserved as their original source files. They require additional data, model downloads, and local helper modules, and retain the original run-directory assumptions. See [EXPERIMENTS.md](EXPERIMENTS.md) before using them. The figure environment is not a full experiment environment.
